#! /bin/bash
##### This is a helper file for building different flavors of ORT
# usage: ./build_master.sh <device-backend> <build-config>
## For example: ./build_master.sh cuda RelWithDebInfo
CUDA_HOME_PATH="/usr/local/cuda-11.4"
TENSORRT_HOME_PATH="/export/local/common/TensorRT-7.0.0.11"
#GLOBAL_PARAMS+=" --cmake_extra_defines onnxruntime_USE_CUDA_NVTX=1 "
GLOBAL_PARAMS+=" --build_shared_lib "
GLOBAL_PARAMS+=" --build_wheel "
GLOBAL_PARAMS+=" --parallel --skip_onnx_tests "
GLOBAL_PARAMS+=" --skip_tests "

case $1 in
  cuda_openmp)
    BUILD_DIR="./build/cuda_openmp"
    OTHER_PARAMS="--use_cuda --cudnn_home ${CUDA_HOME_PATH} --cuda_home ${CUDA_HOME_PATH} --use_openmp"
    ;;
  cuda)
    BUILD_DIR="./build/cuda"
    OTHER_PARAMS="--use_cuda --cudnn_home ${CUDA_HOME_PATH} --cuda_home ${CUDA_HOME_PATH}"
    ;;
  cuda_dnnl)
    BUILD_DIR="./build/cuda_dnnl"
    OTHER_PARAMS="--use_cuda --cudnn_home ${CUDA_HOME_PATH} --cuda_home ${CUDA_HOME_PATH} --use_dnnl --use_mklml"
    ;;
  cpu)
    BUILD_DIR="./build/cpu"
    OTHER_PARAMS=""
    ;;
  trt)
    BUILD_DIR="./build/trt"
    OTHER_PARAMS="--use_tensorrt --tensorrt_home ${TENSORRT_HOME_PATH} --use_cuda --cudnn_home ${CUDA_HOME_PATH} --cuda_home ${CUDA_HOME_PATH}"
    ;;
   *)
    BUILD_DIR="./build/cpu"
    OTHER_PARAMS=""
    ;;
esac

case $2 in
  Debug)
    CONFIG="Debug"
    ;;
  Release)
    CONFIG="Release"
    ;;
  RelWithDebInfo)
    CONFIG="RelWithDebInfo"
    ;;
  *)
    CONFIG="RelWithDebInfo"
    ;;
esac

shift 2

echo ./build.sh --build_dir ${BUILD_DIR} --config ${CONFIG} ${GLOBAL_PARAMS} ${OTHER_PARAMS} $@
./build.sh --build_dir ${BUILD_DIR} --config ${CONFIG} ${GLOBAL_PARAMS} ${OTHER_PARAMS} $@
