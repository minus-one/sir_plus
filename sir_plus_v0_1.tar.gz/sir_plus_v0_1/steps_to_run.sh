#! /bin/bash

####### WARNING: PLEASE READ THROUGH THIS FULLY BEFORE RUNNING THIS SCRIPT
####### THE SCRIPT MAY NOT WORK OUT OF THE BOX. YOU CAN COPY COMMANDS FROM THIS AND RUN IT SEPARATELY

### First we download vanilla ORT. SIR+ is based on ORT version 1.6.
git clone --single-branch -b rel-1.6.0 https://github.com/microsoft/onnxruntime.git sir_plus

#### At this stage, ensure all the build pre-requisites for ORT are installed on your machine - https://github.com/microsoft/onnxruntime/blob/rel-1.6.0/BUILD.md#CUDA

#### Read through the requirements.txt inside sir_plus folder and install those too (numpy & protobuf)

#### Edit build_master.sh and update the CUDA path and the TENSOR_RT paths to point to wherever you have installed cuda and tensor-rt

### Apply the sir_plus patches
cd ./sir_plus/
patch -p1 -i ../sir_plus_include.diff 
patch -p1 -i ../sir_plus_core.diff

### Copy the master build script
cp ../build_master.sh ./

### Run the build
./build_master.sh cuda RelWithDebInfo

### Python wheel and library will be inside build directory
cd ../
ls sir_plus/build/cuda/RelWithDebInfo/
